#a3.w06-carousel

[carousel](https://1101-1-a-web-408630126.vercel.app/1_active/w06-jonas-carousel/carousel-original.html)

![](https://i.imgur.com/r6YOkb8.png)
