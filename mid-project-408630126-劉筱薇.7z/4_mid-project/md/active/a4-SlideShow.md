####a3 .md

[W3S Slide Show](https://1101-1-a-web-408630126.vercel.app/1_active/w06-w3s-slideshow/slideshow.html)

頁面1
![](https://i.imgur.com/J9sOrUu.png)

頁面2

![](https://i.imgur.com/gt4cvwZ.png)

頁面3

![](https://i.imgur.com/M5PPfyf.png)

頁面4

![](https://i.imgur.com/AHNFdo1.png)