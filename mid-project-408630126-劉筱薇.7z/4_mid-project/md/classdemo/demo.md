#class demo

[Vercel app](https://1101-1-a-web-408630126.vercel.app/)

[課堂實作連結](https://1101-1-a-web-408630126.vercel.app/3_classdemo/)

####intro
![](https://i.imgur.com/5nACrsf.png)

####pokemon
![](https://i.imgur.com/ya8CnDs.png)

####image gallery
![](https://i.imgur.com/umF9sTR.png)

####blog
![](https://i.imgur.com/G6ym5GI.png)

####MS clone menu
![](https://i.imgur.com/gGPKPj2.png)

####slide show
![](https://i.imgur.com/sHJ8vte.png)
